package com.raykibul.learnservice;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.IpSecManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.VideoView;

import java.text.SimpleDateFormat;

public class MainActivity extends AppCompatActivity {
 TextView mytextView;
 VideoView videoView;
    private static final String TAG = "MainActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mytextView=findViewById(R.id.textView);
        videoView = findViewById(R.id.videoView);
        videoView.setVideoPath("http://techslides.com/demos/sample-videos/small.mp4");
        videoView.start();

    }



  public void  OnButtonClick(View view){


}



}