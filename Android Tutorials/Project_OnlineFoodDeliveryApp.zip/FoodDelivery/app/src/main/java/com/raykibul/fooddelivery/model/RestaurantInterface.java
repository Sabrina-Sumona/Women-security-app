package com.raykibul.fooddelivery.model;

public interface RestaurantInterface {
    void onRestaurantClick(Restaurant restaurant);
}
