package com.raykibul.fooddelivery.ui.home;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.raykibul.fooddelivery.R;
import com.raykibul.fooddelivery.model.DataController;
import com.raykibul.fooddelivery.model.Restaurant;
import com.squareup.picasso.Picasso;

import java.util.List;

public class HomeRecyclerAdapter extends RecyclerView.Adapter<HomeRecyclerAdapter.viewHolder> {

    List<Restaurant> allRestaurnats;


    public HomeRecyclerAdapter(List<Restaurant> allRestaurnats ) {
        this.allRestaurnats = allRestaurnats;

    }

    @NonNull
    @Override
    public viewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.home_recycler_item,parent,false);

      return new viewHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull viewHolder holder, int position) {
       Restaurant current=allRestaurnats.get(position);
       holder.restaurentName.setText(current.getRestaurantName());
       holder.restaurantDescription.setText(current.getRestaurantDescription());
       Picasso.get().load(current.getRestaurantImgUrl()).fit().into(holder.restaurentImage);

    }

    @Override
    public int getItemCount() {
         if (allRestaurnats==null||allRestaurnats.size()==0){
             return 0;
         }else{
             return allRestaurnats.size();
         }

    }



    public  class viewHolder extends RecyclerView.ViewHolder{
          ImageView restaurentImage;
          TextView restaurentName,restaurantDescription;

        public viewHolder(@NonNull View itemView) {
            super(itemView);

            restaurentImage=itemView.findViewById(R.id.restaurantImageView);
            restaurentName=itemView.findViewById(R.id.restaurantNameTextview);
            restaurantDescription=itemView.findViewById(R.id.restaurntDescriptionTextview);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Restaurant current= allRestaurnats.get(getAdapterPosition());
                    DataController.instance.getRestaurantInterface().onRestaurantClick(current);
                }
            });
        }
    }
}
