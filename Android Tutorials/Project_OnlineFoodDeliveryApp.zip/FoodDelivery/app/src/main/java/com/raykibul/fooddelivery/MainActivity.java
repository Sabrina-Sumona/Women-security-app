package com.raykibul.fooddelivery;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.raykibul.fooddelivery.model.DataController;
import com.raykibul.fooddelivery.model.MenuItem;
import com.raykibul.fooddelivery.model.Restaurant;
import com.raykibul.fooddelivery.model.RestaurantInterface;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements RestaurantInterface {
    private static final String TAG = "MainActivity";
    RestaurantInterface restaurantInterface;
    DataController controller;
    NavController navController;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        BottomNavigationView navView = findViewById(R.id.nav_view);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        restaurantInterface=this;

        controller=DataController.getInstance();
        controller.setRestaurantInterface(restaurantInterface);
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_home, R.id.navigation_dashboard, R.id.navigation_notifications)
                .build();
         navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(navView, navController);

       //  SendDataToFirestore();


    }



    private void SendDataToFirestore() {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        CollectionReference reference = db.collection("Restaurants");
        Restaurant myRestaurant = new Restaurant();
        myRestaurant.setRestaurantName("Rakib Restaurants");
        myRestaurant.setRestaurantDescription("best restaurant in Dhaka");
        myRestaurant.setRestaurantLocation("Dhaka, dhanmondi");
        myRestaurant.setRestaurantImgUrl("https://www.melissahartfiel.com/wp-content/uploads/2013/04/20130426-1304_untitled0051.jpg");
        List<MenuItem> myMenus = new ArrayList<>();

        for (int i=0;i<15;i++){
            myMenus.add(new MenuItem("Mutton Kacchi", "Khub e test",450));
        }
        myRestaurant.setRestaurantMenulist(myMenus);


        reference.add(myRestaurant).addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
            @Override
            public void onComplete(@NonNull Task<DocumentReference> task) {
                if(task.isSuccessful()){
                    Toast.makeText(MainActivity.this, "Restaurant Uploaded", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(MainActivity.this, "SOrry not success", Toast.LENGTH_SHORT).show();
                }

            }
        });

    }

    @Override
    public void onRestaurantClick(Restaurant restaurant) {
         controller.setCurrentMenuItemList(restaurant.getRestaurantMenulist());
         navController.navigate(R.id.action_navigation_home_to_navigation_menu);
    }
}