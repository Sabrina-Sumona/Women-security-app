package com.raykibul.fooddelivery.ui.dashboard;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.raykibul.fooddelivery.R;
import com.squareup.picasso.Picasso;

public class DashboardFragment extends Fragment {

    FirebaseUser user;
    ImageView userprofile;
    TextView emailText,nameText;


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_dashboard, container, false);
         userprofile=root.findViewById(R.id.imageView);
         emailText=root.findViewById(R.id.textView2);
         nameText=root.findViewById(R.id.textView);

         user= FirebaseAuth.getInstance().getCurrentUser();
         if (user!=null){
             emailText.setText("Email:" +user.getEmail());
             nameText.setText("Name: "+user.getDisplayName());
             Picasso.get().load(user.getPhotoUrl()).fit().into(userprofile);

         }


        return root;
    }
}