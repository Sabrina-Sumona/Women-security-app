package com.raykibul.cgpa.home;

import com.raykibul.cgpa.model.Semister;

public interface HomeFragmentInterface {
    void onSemisterItemClick(Semister semister);

}
