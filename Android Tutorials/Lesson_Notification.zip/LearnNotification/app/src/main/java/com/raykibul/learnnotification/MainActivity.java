package com.raykibul.learnnotification;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    NotificationHelper notificationHelper;
    NotificationManager manager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        notificationHelper =new NotificationHelper(this);
        manager=notificationHelper.getManager();

    }


    public void OnNotificationButtonClick(View view){
         NotificationCompat.Builder nb = notificationHelper.getChannelNotification("THis is Title","THIS IS MSG");
         manager.notify(1565,nb.build());
    }
}