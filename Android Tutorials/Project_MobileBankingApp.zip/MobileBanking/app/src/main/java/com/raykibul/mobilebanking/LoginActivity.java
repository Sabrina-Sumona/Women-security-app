package com.raykibul.mobilebanking;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.raykibul.mobilebanking.interfaces.WebService;
import com.raykibul.mobilebanking.model.DataController;
import com.raykibul.mobilebanking.model.MyRetrofit;
import com.raykibul.mobilebanking.model.User;

import java.io.IOException;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {
    EditText phoneNumberText, pinNumberText;
    Button loginButton;
    ProgressBar progressBar;
    WebService service;
    DataController controller;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        InitializeUI();

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (phoneNumberText.getText().toString().equals("")||pinNumberText.getText().toString().equals("")){
                    Toast.makeText(LoginActivity.this, "Please insert PIN and Phone", Toast.LENGTH_SHORT).show();
                }else{
                    progressBar.setVisibility(View.VISIBLE);
                    SendLoginRequest(phoneNumberText.getText().toString(),pinNumberText.getText().toString());
                }

            }
        });
    }

    private void SendLoginRequest(String phoneNumber, String pinNumber) {
        service= MyRetrofit.getinstance();
      /*  Call<ResponseBody> login= service.loginNow(phoneNumber,pinNumber);
        login.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                progressBar.setVisibility(View.GONE);
                if(!response.isSuccessful()){
                    Toast.makeText(LoginActivity.this, "Response Not Success", Toast.LENGTH_SHORT).show();
                    return;
                }
                 String serverMsg="";
                try {
                     serverMsg= response.body().string();

                } catch (IOException e) {
                    e.printStackTrace();
                }
                if (serverMsg.equals("1")){

                    Toast.makeText(LoginActivity.this, "Successful", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(LoginActivity.this,MainActivity.class));
                    finish();
                }else{

                    Toast.makeText(LoginActivity.this, "Login Failed", Toast.LENGTH_SHORT).show();

                }


            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                progressBar.setVisibility(View.GONE);

            }
        });*/

       Call<User> secondlogin =service.secondlogin(phoneNumber,pinNumber);
       secondlogin.enqueue(new Callback<User>() {
           @Override
           public void onResponse(Call<User> call, Response<User> response) {
               progressBar.setVisibility(View.GONE);
               if (!response.isSuccessful()){
                   return;
               }
               User user =response.body();
               if (user==null){
                   Toast.makeText(LoginActivity.this, "User Null", Toast.LENGTH_SHORT).show();
                   return;
               }

               if (user.getUserResponse()!=null&&user.getUserResponse().equals("0")){
                   Toast.makeText(LoginActivity.this, "Login Failed", Toast.LENGTH_SHORT).show();
               }else if (user.getUserResponse()!=null&&user.getUserResponse().equals("1")){
                   controller.setCurrentUser(user);

                   Toast.makeText(LoginActivity.this, "Login Success", Toast.LENGTH_SHORT).show();
                   startActivity(new Intent(LoginActivity.this,MainActivity.class));
                   finish();
               }
           }

           @Override
           public void onFailure(Call<User> call, Throwable t) {

           }
       });

    }


    private void InitializeUI() {
        progressBar=findViewById(R.id.progressBar);
        loginButton=findViewById(R.id.button);
        phoneNumberText=findViewById(R.id.editTextPhone);
        pinNumberText=findViewById(R.id.editTextNumber);
       controller =DataController.getInstance();

    }
}