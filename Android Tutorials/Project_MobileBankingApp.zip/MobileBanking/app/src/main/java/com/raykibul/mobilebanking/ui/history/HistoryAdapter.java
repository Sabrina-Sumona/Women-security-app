package com.raykibul.mobilebanking.ui.history;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.raykibul.mobilebanking.R;
import com.raykibul.mobilebanking.model.History;

import java.util.List;

public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.viewHolder> {
   List<History> myHistories ;

    public HistoryAdapter(List<History> myHistories) {
        this.myHistories = myHistories;
    }

    @NonNull
    @Override
    public viewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.historyitem,parent,false);

       return new viewHolder(view);


    }

    @Override
    public void onBindViewHolder(@NonNull viewHolder holder, int position) {
           History temp = myHistories.get(position);
           holder.historyNumber.setText(temp.getNumber());
           holder.historydate.setText(temp.getDateTime());
           holder.historyType.setText(temp.getType());
           holder.historyAmount.setText(temp.getAmount());

    }

    @Override
    public int getItemCount() {
        if (myHistories==null||myHistories.size()==0){
            return 0;
        }else{
          return   myHistories.size();
        }
    }

    public class viewHolder extends RecyclerView.ViewHolder{
        TextView historyType,historyAmount,historydate,historyNumber;



        public viewHolder(@NonNull View itemView) {
            super(itemView);
            historyAmount=itemView.findViewById(R.id.historyAmountTextview);
            historyType=itemView.findViewById(R.id.historyTYpeTextview);
            historydate=itemView.findViewById(R.id.historyDateTextview);
            historyNumber=itemView.findViewById(R.id.historyNumberTextview);
        }
    }
}
