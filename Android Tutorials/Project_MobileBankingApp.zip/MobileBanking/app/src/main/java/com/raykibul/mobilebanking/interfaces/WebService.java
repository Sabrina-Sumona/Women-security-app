package com.raykibul.mobilebanking.interfaces;


import com.raykibul.mobilebanking.model.History;
import com.raykibul.mobilebanking.model.User;

import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface WebService {

    @GET("login.php")
    Call<ResponseBody> loginNow(@Query("number") String number,
                                @Query("pin") String pin);
    @GET("secondlogin.php")
    Call<User> secondlogin(@Query("number") String number,
                                @Query("pin") String pin);

    @FormUrlEncoded
    @POST("recharge.php")
    Call<ResponseBody> rechargeNow(@Field("number") String number,
                                   @Field("amount") String amount,
                                   @Field("userPhone") String userPhone,
                                   @Field("userPin") String userPin );

    @FormUrlEncoded
    @POST("cashout.php")
    Call<ResponseBody> cashoutNow(@Field("number") String number,
                                   @Field("amount") String amount,
                                   @Field("userPhone") String userPhone,
                                   @Field("userPin") String userPin );


    @GET("history.php")
    Call<List<History>> getHistoryList(@Query("number") String number,
                                 @Query("pin") String pin);

}
