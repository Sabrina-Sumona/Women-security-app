package com.raykibul.mobilebanking.model;

public class DataController {

    public  static  DataController instance;

    public static DataController getInstance(){
        if (instance==null) {
            instance = new DataController();
        }
            return instance;

    }

    User currentUser;


    public User getCurrentUser() {
        return currentUser;
    }

    public void setCurrentUser(User currentUser) {
        this.currentUser = currentUser;
    }
}
