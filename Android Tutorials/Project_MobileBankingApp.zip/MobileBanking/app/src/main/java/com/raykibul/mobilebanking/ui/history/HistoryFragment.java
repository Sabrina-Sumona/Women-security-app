package com.raykibul.mobilebanking.ui.history;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.raykibul.mobilebanking.R;
import com.raykibul.mobilebanking.interfaces.WebService;
import com.raykibul.mobilebanking.model.DataController;
import com.raykibul.mobilebanking.model.History;
import com.raykibul.mobilebanking.model.MyRetrofit;
import com.raykibul.mobilebanking.model.User;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HistoryFragment extends Fragment {
     View root;
     List<History> allHistory = new ArrayList<>();
     RecyclerView recyclerView;
     HistoryAdapter adapter ;
     WebService service;

     User user;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
      root = inflater.inflate(R.layout.fragment_history,container,false);
      recyclerView=root.findViewById(R.id.historyrecycler);
      recyclerView.setHasFixedSize(true);
      recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

      service=MyRetrofit.getinstance();
      user= DataController.instance.getCurrentUser();
      LoadHistory();

      return root;
    }

    private void LoadHistory() {
        Call<List<History>> loadHistory=service.getHistoryList(user.getUserPhone(),user.getUserPin());
        loadHistory.enqueue(new Callback<List<History>>() {
            @Override
            public void onResponse(Call<List<History>> call, Response<List<History>> response) {
                if (!response.isSuccessful()){
                    Toast.makeText(getActivity(), "Response Failed"+response.code(), Toast.LENGTH_SHORT).show();
                    return;
                }
                 allHistory=response.body();
                 Toast.makeText(getActivity(), "Size "+allHistory.get(1).getNumber(), Toast.LENGTH_SHORT).show();
                 adapter= new HistoryAdapter(allHistory);
                 recyclerView.setAdapter(adapter);
            }

            @Override
            public void onFailure(Call<List<History>> call, Throwable t) {
                Toast.makeText(getActivity(), "Failed "+t.toString(), Toast.LENGTH_SHORT).show();

            }
        });

    }
}
