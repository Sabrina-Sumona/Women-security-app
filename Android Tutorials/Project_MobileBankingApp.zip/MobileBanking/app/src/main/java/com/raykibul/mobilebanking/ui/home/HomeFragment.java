package com.raykibul.mobilebanking.ui.home;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.navigation.Navigation;

import com.raykibul.mobilebanking.R;

public class HomeFragment extends Fragment implements View.OnClickListener {
   ImageView rechargeImage,cashoutImageview,historyImageView,supportImageView,accounImageView;




   View root;

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        root = inflater.inflate(R.layout.fragment_home, container, false);
         rechargeImage=root.findViewById(R.id.rechargeImageView);
         cashoutImageview=root.findViewById(R.id.cashoutImageView);
         historyImageView=root.findViewById(R.id.historyImageView);
         supportImageView=root.findViewById(R.id.chatsupportImageVIew);
         accounImageView=root.findViewById(R.id.accountSettingImageVIew);
         accounImageView.setOnClickListener(this);
         supportImageView.setOnClickListener(this);
         historyImageView.setOnClickListener(this);
         cashoutImageview.setOnClickListener(this);
         rechargeImage.setOnClickListener(this);

        return root;
    }

    @Override
    public void onClick(View v) {
        int id=v.getId();
        switch (id){
            case R.id.rechargeImageView:
                RechargeImageClick();
                break;
            case R.id.cashoutImageView:
                Cashout();
                break;
            case R.id.historyImageView:
                Navigation.findNavController(root).navigate(R.id.action_nav_home_to_nav_history);
                break;
            case R.id.chatsupportImageVIew:
                RedirectToWhatsapp();
                break;
            case R.id.accountSettingImageVIew:
                Navigation.findNavController(root).navigate(R.id.action_nav_home_to_nav_account);
                break;

        }
    }

    private void RedirectToWhatsapp() {
        String url = "https://api.whatsapp.com/send?phone=018121212";
        Intent intent = new Intent(Intent.ACTION_VIEW);

        intent.setData(Uri.parse(url));
        startActivity(intent);


    }


    private void Cashout() {
        Navigation.findNavController(root).navigate(R.id.action_nav_home_to_nav_cashout);

    }

    private void RechargeImageClick() {
        Navigation.findNavController(root).navigate(R.id.action_nav_home_to_nav_recharge);

    }
}