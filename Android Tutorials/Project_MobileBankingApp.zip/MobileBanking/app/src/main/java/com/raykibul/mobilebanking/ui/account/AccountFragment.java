package com.raykibul.mobilebanking.ui.account;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.raykibul.mobilebanking.R;
import com.raykibul.mobilebanking.model.DataController;
import com.raykibul.mobilebanking.model.User;

public class AccountFragment extends Fragment {
    View root;

    TextView nametext,phonetext,userbalancetext;
    User user;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
         root =inflater.inflate(R.layout.fragment_account,container,false);
         nametext=root.findViewById(R.id.userNameTexviewac);
         phonetext=root.findViewById(R.id.userPhoneTExtviw);
         userbalancetext=root.findViewById(R.id.userBalanceTvAc);
         user= DataController.instance.getCurrentUser();

         nametext.setText("User Name: "+user.getUserName());
         phonetext.setText("Phone :"+user.getUserPhone());
         userbalancetext.setText("Balance: "+user.getUserBalance());

         return root;
    }
}
