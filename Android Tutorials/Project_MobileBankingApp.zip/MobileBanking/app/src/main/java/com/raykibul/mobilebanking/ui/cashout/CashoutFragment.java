package com.raykibul.mobilebanking.ui.cashout;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.raykibul.mobilebanking.R;
import com.raykibul.mobilebanking.interfaces.WebService;
import com.raykibul.mobilebanking.model.DataController;
import com.raykibul.mobilebanking.model.MyRetrofit;
import com.raykibul.mobilebanking.model.User;

import java.io.IOException;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CashoutFragment extends Fragment {
    View root;
    EditText agentNumber,amountText;
    Button cashoutButton;
    User user;
    WebService service;
    ProgressBar progressBar;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        root =inflater.inflate(R.layout.fragment_cashout,container,false);
        agentNumber =root.findViewById(R.id.editTextPhone2);
        amountText=root.findViewById(R.id.editTextNumber2);
        cashoutButton =root.findViewById(R.id.button2);
        user = DataController.instance.getCurrentUser();
        service= MyRetrofit.getinstance();
        progressBar=root.findViewById(R.id.rechargeProgressbar);
        cashoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(agentNumber.getText().toString().equals("")||amountText.getText().toString().equals("")){
                    Toast.makeText(getActivity(), "Please Insert All Inputs", Toast.LENGTH_SHORT).show();
                }else{
                    progressBar.setVisibility(View.VISIBLE);
                    cashOutNow(agentNumber.getText().toString(),amountText.getText().toString());
                }

            }
        });

        return root;
    }

    private  void cashOutNow(String number, String amount){

        Call<ResponseBody> rechargeNow= service.cashoutNow(number,amount,user.getUserPhone(),user.getUserPin());
        rechargeNow.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                progressBar.setVisibility(View.GONE);
                if (!response.isSuccessful()){
                    Toast.makeText(getActivity(), "Request Failed"+response.code(), Toast.LENGTH_SHORT).show();
                    return;
                }


                String res="";
                try {
                    res= response.body().string();
                    if (res.equals("1")){
                        Toast.makeText(getActivity(), "Cashout Successful", Toast.LENGTH_SHORT).show();
                    }else{
                        Toast.makeText(getActivity(), "Cashout Failed", Toast.LENGTH_SHORT).show();

                    }


                } catch (IOException e) {
                    e.printStackTrace();
                }


            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(getActivity(), "Request Failed"+t.toString(), Toast.LENGTH_SHORT).show();

            }
        });
    }

}
