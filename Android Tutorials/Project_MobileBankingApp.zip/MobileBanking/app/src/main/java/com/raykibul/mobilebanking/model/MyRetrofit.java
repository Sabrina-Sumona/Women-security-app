package com.raykibul.mobilebanking.model;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.raykibul.mobilebanking.interfaces.WebService;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MyRetrofit {
    public  static Retrofit api;
    public  static  WebService service;

    public  static WebService getinstance(){

        if (service==null) {
            if (api == null) {
                Gson gson = new GsonBuilder()
                         .setLenient()
                         .create();


                api = new Retrofit.Builder()
                        .baseUrl("https://raykibul.com/freeapi/")
                        .addConverterFactory(GsonConverterFactory.create(gson))
                        .build();

            }
            service = api.create(WebService.class);

            return service;
        }else{
            return service;
        }
    }



}
